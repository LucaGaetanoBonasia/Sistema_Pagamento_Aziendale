﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pagamento_Aziendale
{

    internal class LavoratoreFullTime : Lavoratore
    {

        public decimal StipendioBase { get; set; }

       
        public LavoratoreFullTime(string nome, string cognome, decimal stipendioBase) : base(nome, cognome)
        {
            StipendioBase = stipendioBase;
        }

        
        public override decimal CalcolaStipendio()
        {
            return StipendioBase;
        }
    }
}
