﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pagamento_Aziendale
{
    // Questa classe rappresenta un lavoratore assunto a tempo pieno.
    // Nella teoria dei sistemi a oggetti, è una specializzazione della classe Lavoratore:
    // prende la struttura base e la completa con regole più specifiche.
    internal class LavoratoreFullTime : Lavoratore
    {
        // Lo stipendio base è la retribuzione fissa del lavoratore full-time.
        public decimal StipendioBase { get; set; }

        // Il costruttore riceve i dati fondamentali del lavoratore
        // e aggiunge il valore dello stipendio previsto per chi lavora a tempo pieno.
        public LavoratoreFullTime(string nome, string cognome, decimal stipendioBase) : base(nome, cognome)
        {
            StipendioBase = stipendioBase;
        }

        // Implementazione concreta del calcolo dello stipendio.
        // Per un full-time, la teoria è semplice: lo stipendio coincide con quello base.
        public override decimal CalcolaStipendio()
        {
            return StipendioBase;
        }
    }
}
