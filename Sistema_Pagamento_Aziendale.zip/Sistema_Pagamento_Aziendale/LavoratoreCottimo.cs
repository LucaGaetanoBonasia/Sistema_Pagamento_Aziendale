﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pagamento_Aziendale
{
    // Questa classe rappresenta un lavoratore pagato "a cottimo",
    // cioè in base alla quantità di pezzi prodotti.
    // Nella teoria dei modelli astratti, è una variante del concetto di lavoratore
    // che collega il salario direttamente alla produttività.
    internal class LavoratoreCottimo : Lavoratore
    {
        // Numero di pezzi che il lavoratore ha realizzato.
        public decimal PezziProdotti { get; set; }

        // Quanto vale economicamente ogni singolo pezzo prodotto.
        public decimal CostoPerPezzo { get; set; }

        // Il costruttore raccoglie i dati personali e le metriche
        // che determinano lo stipendio nel lavoro a cottimo.
        public LavoratoreCottimo(string nome, string cognome, decimal pezziProdotti, decimal costoPerPezzo)
            : base(nome, cognome)
        {
            PezziProdotti = pezziProdotti;
            CostoPerPezzo = costoPerPezzo;
        }

        // Il calcolo dello stipendio segue la logica tipica di questa categoria:
        // salario proporzionale alla produzione totale.
        public override decimal CalcolaStipendio()
        {
            return PezziProdotti * CostoPerPezzo;
        }
    }
}
