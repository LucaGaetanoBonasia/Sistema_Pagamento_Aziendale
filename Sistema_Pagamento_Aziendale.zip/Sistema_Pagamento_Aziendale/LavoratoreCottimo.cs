﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pagamento_Aziendale
{

    internal class LavoratoreCottimo : Lavoratore
    {
   
        public decimal PezziProdotti { get; set; }

      
        public decimal CostoPerPezzo { get; set; }

      
        public LavoratoreCottimo(string nome, string cognome, decimal pezziProdotti, decimal costoPerPezzo)
            : base(nome, cognome)
        {
            PezziProdotti = pezziProdotti;
            CostoPerPezzo = costoPerPezzo;
        }

  
        public override decimal CalcolaStipendio()
        {
            return PezziProdotti * CostoPerPezzo;
        }
    }
}
