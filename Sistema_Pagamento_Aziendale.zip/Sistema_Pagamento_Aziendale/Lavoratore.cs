﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pagamento_Aziendale
{
    // Classe astratta che definisce il concetto generale di lavoratore.
    // In teoria dei modelli, rappresenta un'entità base da cui derivano tipi più specifici.
    abstract class Lavoratore
    {
        // Identità minima del lavoratore: nome e cognome.
        public string Nome { get; set; }
        public string Cognome { get; set; }

        // Ogni lavoratore deve avere almeno i dati anagrafici principali.
        public Lavoratore(string nome, string cognome)
        {
            Nome = nome;
            Cognome = cognome;
        }

        // Metodo astratto: ogni tipo concreto di lavoratore calcola lo stipendio secondo regole proprie.
        // Qui esiste solo l'idea, non l'implementazione.
        public abstract decimal CalcolaStipendio();

        // Restituisce una breve descrizione del lavoratore.
        public string Dettagli()
        {
            return $"nome:{Nome}, cognome: {Cognome}";
        }
    }
}
