﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pagamento_Aziendale
{

    abstract class Lavoratore
    {
     
        public string Nome { get; set; }
        public string Cognome { get; set; }

  
        public Lavoratore(string nome, string cognome)
        {
            Nome = nome;
            Cognome = cognome;
        }

     
        public abstract decimal CalcolaStipendio();

    
        public string Dettagli()
        {
            return $"nome:{Nome}, cognome: {Cognome}";
        }
    }
}
