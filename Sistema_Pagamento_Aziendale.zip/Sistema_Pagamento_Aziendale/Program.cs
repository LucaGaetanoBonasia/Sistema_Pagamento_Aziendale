﻿using System;

namespace Sistema_Pagamento_Aziendale
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creiamo una lista che contiene diversi tipi di lavoratori.
            // Da un punto di vista teorico è un esempio di polimorfismo:
            // oggetti diversi condividono la stessa interfaccia astratta "Lavoratore".
            List<Lavoratore> lavoratori = new List<Lavoratore>
            {
                new LavoratoreFullTime("Mario", "Rossi", 2500m),
                new LavoratoreCottimo("Luigi", "Verdi", 150, 20m)
            };

            // Il ciclo mostra come il programma tratta ogni lavoratore
            // allo stesso modo, anche se ognuno calcola lo stipendio a suo modo.
            foreach (var lavoratore in lavoratori)
            {
                Console.WriteLine(lavoratore.Dettagli());
                Console.WriteLine($"Stipendio: {lavoratore.CalcolaStipendio()}");
                Console.WriteLine();
            }
        }
    }
}
