﻿using System;

namespace Sistema_Pagamento_Aziendale
{
    internal class Program
    {
        static void Main(string[] args)
        {
        
            List<Lavoratore> lavoratori = new List<Lavoratore>
            {
                new LavoratoreFullTime("Mario", "Rossi", 2500m),
                new LavoratoreCottimo("Luigi", "Verdi", 150, 20m)
            };

            foreach (var lavoratore in lavoratori)
            {
                Console.WriteLine(lavoratore.Dettagli());
                Console.WriteLine($"Stipendio: {lavoratore.CalcolaStipendio()}");
                Console.WriteLine();
            }
        }
    }
}
